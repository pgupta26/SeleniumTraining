package com.qa.tests;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qa.base.TestBase;
import com.qa.client.RestClient;
import com.qa.data.Users;

public class PostAPITest extends TestBase {
	
	TestBase testBase;;
	String serviceUrl;
	String apiUri;
	String  url;
	RestClient restClient;
	
	@BeforeMethod
	public void setUp() throws ClientProtocolException, IOException {
		testBase=new TestBase();
		serviceUrl=prop.getProperty("url");
		apiUri=prop.getProperty("uri");
		url=serviceUrl+apiUri;
	}
	
	@Test
	public void postAPITest() throws ClientProtocolException, IOException {
		restClient=new RestClient();
		HashMap<String,String> reqHeader=new HashMap<String,String>();
		reqHeader.put("Content-Type", "application/json");
		
		//Jackson API : It is used for Marshaling and Unmarshalling
		//Marshaling - Conversion of Java Object to Json Object
		//Unmarshalling - Conversion of Json Object to Java Object
		ObjectMapper mapper=new ObjectMapper();
		Users users=new Users("Parshant","Tester");
		
		//object to JSON file
		mapper.writeValue(new File("C:/Parshant/Selenium Projects/RestAPITest/src/com/qa/data/Users.json"), users);
		
		//object to JSON in string
		String usersJsonString=mapper.writeValueAsString(users);	
		
		CloseableHttpResponse closeablbHttpResponse=restClient.post(url,usersJsonString,reqHeader);
		
		//1. Status Code
		int statusCode=closeablbHttpResponse.getStatusLine().getStatusCode();
		System.out.println("Status Code Response: "+statusCode);
		
		//2. JsonString
		String responseString=EntityUtils.toString(closeablbHttpResponse.getEntity(),"UTF-8").toString();
		
		JSONObject responseJson=new JSONObject(responseString);
		System.out.println("The response fron API is: "+responseJson);
		
		//JSON to Java Object
		Users usersResObj=mapper.readValue(responseString, Users.class);
		
		Assert.assertEquals(usersResObj.getName(), users.getName());
		Assert.assertEquals(usersResObj.getJob(), users.getJob());
	}
}
