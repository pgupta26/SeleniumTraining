package com.qa.base;

import java.io.FileReader;
import java.util.Properties;

public class TestBase {
	public Properties prop;
	public TestBase() {
		try{
			prop=new Properties();
			FileReader reader=new FileReader(System.getProperty("user.dir")+"/src/com/qa/config/config.properties");
			prop.load(reader);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

}
